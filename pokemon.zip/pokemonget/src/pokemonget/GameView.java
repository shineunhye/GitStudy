package pokemonget;
import java.awt.*;
import javax.swing.*;
public class GameView extends JPanel {
	Image player,pokemon,back;
	int x=350;
	int y=850;

	String[] img={"trainer_mini_man_1_Rt.gif","trainer_mini_man_1_Lt.gif"};
	String[] img2={"magcargo.gif","ggobugi.gif","pairi.gif"};
	
	
	public GameView(){
		player=Toolkit.getDefaultToolkit().getImage("img\\trainer_mini_man_1_Rt.gif");
		back=Toolkit.getDefaultToolkit().getImage("img\\back.png");
	}
	
	public void playersetImage(int no){
		player=Toolkit.getDefaultToolkit().getImage("img\\"+img[no]);
	}
	
	public void pokemonsetImage(int no){
		pokemon=Toolkit.getDefaultToolkit().getImage("img\\"+img2[no]);
	}
	
	@Override
	public void paint(Graphics g) {
		g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
		g.drawImage(player, x, y, this);
		g.drawImage(pokemon, 300, 400, this);
	}	
}
