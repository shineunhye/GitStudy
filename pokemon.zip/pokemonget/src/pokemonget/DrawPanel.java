package pokemonget;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DrawPanel extends JPanel{
	
	public DrawPanel(){
	}
//		for (PosImageIcon icon : list) // 이미지를 그려줌
//		{
//			xPos=170;
//			yPos=(2+icon.pY) % 680;
//			icon.pX=xPos;
//			icon.pY=yPos;
//			icon.paint(g2d); 
//			
//			if(list.get(0).pY > 800) { //첫번째 이미지가 y축 580을 넘어가면 없애줌.
//				list.remove(0);
//			}
//		}
	}











