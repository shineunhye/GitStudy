package pokemonget;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class MainClass extends JFrame implements KeyListener,ActionListener {
	GameView gv=new GameView();
	JMenuBar bar=new JMenuBar();
	JButton start;
	int type=0;
	public static final int FRAME_WIDTH=800;
	public static final int FRAME_HEIGHT=1000;
	
	MainClass(){
		start=new JButton("START");
		start.addActionListener(this);
		bar.add(start);
		setJMenuBar(bar);
		add("Center",gv);
		setSize(FRAME_WIDTH,FRAME_HEIGHT);
		setVisible(true);
		addKeyListener(this);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		switch(e.getKeyCode()){
		case KeyEvent.VK_RIGHT:
			type=0;
			gv.playersetImage(0);
			gv.x+=9;
			if(gv.x>600)
				gv.x=0;
			break;
		case KeyEvent.VK_LEFT:
			type=1;
			gv.playersetImage(1);
			gv.x-=9;
			if(gv.x<0)
				gv.x=600;
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}
	public static void main(String[] args) {
		new MainClass();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==start){
			int no=(int)(Math.random()*3);
			gv.pokemonsetImage(no);
		}
		
	}

}
